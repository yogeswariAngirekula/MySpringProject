# myproject
This code purpose is to perform Employee management System - 

-> CRUD(batch insertion) using MyBatis Framework,Sql (backend),Postman tool.
-> Anyone can do insertion, updation, deletion will be allowed only by the registered user, who logged In.
-> If logged In, there comes a message already logged In.
-> User login operation, login logout time update, total login time which were another database table
-> Login table and Employee tables were interlinked using foreign key in database.
-> Updating the time when the details got updated in employee table. 
-> In case of deletion -> the status will get set to inactive but the details will not get deleted.
